# ----------------------------------------------------------------------------
# Program: MlengelaWebScrape
# Programmer: Daudi Mlengela (dnlengela@cnm.edu)(mlengelad@gmail.com)
# Instructor: Thomas Gitierrez (tgutierrez@cnm.edu)
# Date: Decmeber 10th, 2022
# Purpose: Creating a web scraper in python to gather data from websites
# using BeautifulSoup, request, and URLLib
# ----------------------------------------------------------------------------

from urllib.request import urlopen

from bs4 import BeautifulSoup

# REGEX WEBSCRAPE
# import re

# webpage = urlopen('https://www.python.org/jobs').read().decode()
# # print(webpage)

# # <a href="/jobs/6981/">Full Stack Python Developer</a> #This is what we're searching for in the webpage

# p = re.compile('<a href="(/jobs/\\d+)/">(.*?)</a>')
# for url, name in p.findall(webpage):
#     print("{} ({})".format(name,url))

# Beautiful Soup Webscrape 
webpage = urlopen('https://www.python.org/jobs').read()
soup = BeautifulSoup(webpage,'html.parser')
# print(soup)
# print(soup.prettify())

def pyJobSectionSearch():
    jobs = set()

    for job in soup.body.section('h2'):    
        print("THIS IS JOB:\n",job)
        print("THIS IS THE JOB.A.STRING:",job.a.string)
        print("THIS IS THE JOB.A[HREF]:",job.a['href'])
        jobs.add('{} ({})'.format(job.a.string,job.a['href']))

    # print('\n'.join(jobs))

# # print(soup.find('a'))
# aTag = soup.find('a')
# print(aTag.getText())
# print(aTag.get('href'))

def pyJobFindAll():
    print("pyJobFindAll: 'a', href")
    for a in soup.find_all('a',href=True):
        print("Found:", a.getText())
        print("Found the URL:",a['href'])
        print()

# pyJobFindAll()

# # print(soup.select('h2'))
# elems = soup.select('a')
# # print(elems)
# print(type(elems))
# print(len(elems))
# print(type(elems[0]))
# print(elems[0].getText())
# for idx, i in enumerate(elems):
#     print(elems[idx].getText())

# for item in soup.find_all('span',class_="listing-company-name"):
#     print(item)

def pyFindAll():
    print("ALL JOBS")
    pyJobsSelect = []
    for a in soup.select(' h2 > span.listing-company-name > a'):
        print("TEXT:", a.getText())
        print("URL:", a['href'])
        pyJobsSelect.append('{} - ({})'.format(a.getText(),a['href']))
    print('\n\n'.join(pyJobsSelect))
    print(len(pyJobsSelect))

pyFindAll()
